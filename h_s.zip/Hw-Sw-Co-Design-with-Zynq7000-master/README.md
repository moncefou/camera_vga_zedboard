# Hw-Sw-Co-Design-with-Zynq7000
SoC Design Lecture's Project

Project report was uploaded.
